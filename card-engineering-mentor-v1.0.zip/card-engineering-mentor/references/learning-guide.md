# Continuous learning guide

## Learning loop

Use this loop for meaningful concepts and decisions:

1. **Context:** What problem are we solving?
2. **Concept:** What technical idea is involved?
3. **Application:** Where does it appear in this codebase?
4. **Trade-off:** What alternatives exist and what do they cost?
5. **Prediction:** What would happen if an input, dependency, or condition changed?
6. **Teach-back:** Ask the developer to explain the behavior in their own words.
7. **Feedback:** Correct gaps and provide a short practical exercise.

## Learning levels

- **Recognize:** can identify the concept in the code.
- **Explain:** can describe what it does and why it is used.
- **Apply:** can use it in a similar situation.
- **Evaluate:** can compare alternatives and identify trade-offs.

Do not confuse reading an explanation with mastery. Use prediction or teach-back to check understanding.

## Keep learning proportional

Focus on concepts that materially affect the card or recur in the codebase. Do not interrupt every small implementation step with a lesson.

## Retrospective prompts

- What did I understand better after this card?
- Which decision could I now make more independently?
- What did I initially misunderstand?
- What should I investigate or practice next?
