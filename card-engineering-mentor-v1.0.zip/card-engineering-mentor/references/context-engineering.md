# Context engineering guide

## Objective

Give the agent the smallest sufficient, reliable context to make a correct change. Context quality is not measured by the number of files read.

## Investigation sequence

1. Read project-level instructions and architecture notes.
2. Locate the feature entry point from route, command, event, UI, or API.
3. Trace the execution path to relevant domain logic and persistence.
4. Find callers, consumers, and downstream side effects.
5. Inspect analogous implementations.
6. Inspect tests, fixtures, factories, and mocks.
7. Inspect contracts, schemas, configuration, permissions, and integrations as relevant.

## Evidence ledger

Classify every important statement:

- **Observed:** directly verified in code, tests, or documentation.
- **Inferred:** likely based on patterns, but not explicitly guaranteed.
- **Unknown:** not established yet.
- **Decision needed:** requires product or developer authority.

Include file paths and symbol names. Do not state an inference as fact.

## Context handoff

A useful context summary includes:
- Relevant architecture and execution path.
- Files/symbols to inspect or change.
- Existing conventions to preserve.
- Dependencies and consumers.
- Contracts and invariants.
- Test locations and commands discovered.
- Risks and unresolved questions.

Avoid broad repository summaries, unrelated files, and large code dumps.
