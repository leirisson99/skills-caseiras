# Planning guide

## Card decomposition

Convert the card into observable behavior. Prefer statements that can be demonstrated or tested.

For each requirement, capture:
- Actor or system initiating the behavior.
- Preconditions.
- Input or event.
- Expected outcome.
- Side effects.
- Failure or rejection behavior.

## Acceptance criteria

Write criteria that are:
- Observable from outside the implementation where possible.
- Specific enough to test.
- Independent of implementation details unless a technical constraint is required.
- Traceable to a requirement or confirmed business rule.

Avoid vague criteria such as "works correctly" or "handles errors".

## Input/output examples

For non-trivial behavior, include examples such as:

| Scenario | Input | Expected output/state | Side effect |
|---|---|---|---|
| Valid request | Concrete example | Expected result | Expected change |
| Invalid request | Concrete example | Validation error | No mutation |
| Boundary case | Limit value | Defined behavior | Defined effect |

Do not invent examples that imply unconfirmed business rules. Label proposed examples as needing confirmation.

## Design trade-offs

For each consequential choice, compare:
- Simplicity.
- Fit with existing architecture.
- Maintainability.
- Testability.
- Performance and scalability when relevant.
- Security and data integrity.
- Migration and compatibility cost.

Recommend one option and explain why. Do not present every possible architecture.
