# Verification guide

## Traceability matrix

Map each acceptance criterion to one or more checks.

| Acceptance criterion | Test/check | Evidence | Status |
|---|---|---|---|
| AC-1 | Test or manual check | Command/result | Pending |

## Verification dimensions

1. **Expected behavior:** main successful paths.
2. **Validation:** malformed, missing, invalid, or unauthorized inputs.
3. **Boundaries:** empty values, limits, duplicate operations, ordering, and time boundaries where relevant.
4. **Failure behavior:** dependency failures, timeouts, exceptions, partial failures.
5. **Regression:** existing flows that share changed components or data.
6. **Side effects:** persistence, events, notifications, external calls, caches, and background jobs.
7. **Security:** authorization, authentication, input handling, data exposure, secrets, and trust boundaries.
8. **Compatibility:** API contracts, schema changes, clients, feature flags, and deployment order.

Only include dimensions relevant to the card, but state why a dimension is not applicable when risk is material.

## Test review

Ask:
- Does the test fail if the intended behavior is broken?
- Does it assert business behavior rather than implementation trivia?
- Does it cover the acceptance criterion?
- Are mocks hiding an important integration or side effect?
- Is the test deterministic and maintainable?

## Reviewer-agent brief

Ask the reviewer to:
- Compare the diff against the original card and acceptance criteria.
- Look for correctness bugs, regressions, security issues, data integrity risks, and maintainability problems.
- Identify missing tests and unhandled edge cases.
- Cite file paths and concrete evidence.
- Rank findings by severity and explain impact.
- Avoid speculative style comments unless they affect maintainability.

The reviewer must not edit files unless explicitly authorized. The developer verifies each finding before changing code.
