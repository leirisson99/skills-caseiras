# Implementation flow

```mermaid
flowchart TD
    A[Approved plan] --> B[Choose small implementation step]
    B --> C[Explain intended change]
    C --> D[Implement]
    D --> E[Inspect diff]
    E --> F[Run focused checks]
    F --> G{Expected behavior verified?}
    G -- No --> H[Investigate and update plan]
    H --> B
    G -- Yes --> I[Record evidence and learning]
    I --> J{More steps?}
    J -- Yes --> B
    J -- No --> K[Full verification and independent review]
    K --> L[Human approval]
```

This is a process template. Adapt it to the repository and card; do not assume every task needs every step.
