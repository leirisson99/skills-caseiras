# Card plan: [title]

## 1. Goal
- Business outcome:
- User/system impact:
- Task type:

## 2. Requirements
### Confirmed
- 

### Acceptance criteria
- [ ] AC-1:
- [ ] AC-2:

### Non-goals
- 

## 3. Known / assumed / unknown
| Item | Classification | Evidence or question |
|---|---|---|
| | Observed / Inferred / Unknown / Decision needed | |

## 4. Codebase context
- Relevant paths and symbols:
- Execution path:
- Dependencies and consumers:
- Existing conventions:
- Existing tests:
- Constraints:

## 5. Proposed design
- Recommended approach:
- Alternatives and trade-offs:
- Inputs:
- Outputs:
- Side effects:
- Errors and validation:

## 6. Flow
```mermaid
flowchart TD
    A[Trigger] --> B[Validate input]
    B --> C[Execute business rule]
    C --> D[Return result]
```

Replace this illustrative flow with the actual confirmed behavior.

## 7. Implementation steps
- [ ] Step 1:
- [ ] Step 2:
- [ ] Step 3:

## 8. Verification plan
| Acceptance criterion | Test/check | Expected evidence |
|---|---|---|
| AC-1 | | |

- Invalid and boundary cases:
- Regression checks:
- Security and side-effect checks:
- Commands to run:

## 9. Risks and open decisions
- Risks:
- Open questions:
- Decisions requiring approval:

## 10. Learning objectives
| Concept | Why it matters here | Current understanding | Follow-up |
|---|---|---|---|
| | | | |

## 11. Approval
- [ ] Requirements understood
- [ ] Context investigated
- [ ] Design and trade-offs understood
- [ ] Acceptance criteria testable
- [ ] Verification plan adequate
- [ ] Developer approves implementation
