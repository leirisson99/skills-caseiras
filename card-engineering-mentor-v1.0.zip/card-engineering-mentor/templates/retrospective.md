# Technical retrospective: [card title]

## Delivery
- Outcome:
- Status: Completed and verified / Completed with limitations / Blocked / Not implemented
- Tests actually run and results:

## Decisions
- Important technical decisions:
- Alternatives considered:
- Why the chosen approach was appropriate:

## Verification
- Acceptance criteria satisfied:
- Evidence:
- Known limitations or residual risks:

## Learning
- Concepts learned:
- What I can now explain independently:
- What remains unclear:
- Initial assumptions corrected:

## Next improvement
- One technical practice to strengthen:
- One workflow improvement for the next card:
